// Sayfa başına gösterilecek araç sayısı
const itemsPerPage = 8;
let currentPage = 1;
let totalCars = document.querySelectorAll('.car-card').length;
let totalPages = Math.ceil(totalCars / itemsPerPage);

const carContainer = document.getElementById('carContainer');
const paginationContainer = document.createElement('div');
paginationContainer.classList.add('pagination');




// Filtreleme formu submit işlemi
document.getElementById('filterForm').addEventListener('submit', function(event) {
  event.preventDefault();
  
  const city = document.getElementById('city').value;
  const minPrice = document.getElementById('minPrice').value;
  const maxPrice = document.getElementById('maxPrice').value;
  const minYear = document.getElementById('minYear').value;
  const maxYear = document.getElementById('maxYear').value;
  const fuel = document.getElementById('fuel').value;
  const transmission = document.getElementById('transmission').value;
  const color = document.getElementById('color').value;
  const model = document.getElementById('model').value;

  filterCars(city, minPrice, maxPrice, minYear, maxYear, fuel, transmission, color, model);
});

// Arabaları filtreleme
function filterCars(city, minPrice, maxPrice, minYear, maxYear, fuel, transmission, color, model) {
  const carCards = document.querySelectorAll('.car-card');
  carContainer.innerHTML = ''; // Önceki araçları temizleyin
  
  carCards.forEach((card) => {
    const carCity = card.getAttribute('data-city');
    const carPrice = parseInt(card.getAttribute('data-price'));
    const carYear = parseInt(card.getAttribute('data-year'));
    const carFuel = card.getAttribute('data-fuel');
    const carTransmission = card.getAttribute('data-transmission');
    const carColor = card.getAttribute('data-color');
    const carModel = card.getAttribute('data-model');

    let matchesFilter = true;

    // Filtreleme şartları
    if (city && city !== '' && carCity !== city) {
      matchesFilter = false;
    }
    if (minPrice && minPrice !== '' && carPrice < minPrice) {
      matchesFilter = false;
    }
    if (maxPrice && maxPrice !== '' && carPrice > maxPrice) {
      matchesFilter = false;
    }
    if (minYear && minYear !== '' && carYear < minYear) {
      matchesFilter = false;
    }
    if (maxYear && maxYear !== '' && carYear > maxYear) {
      matchesFilter = false;
    }
    if (fuel && fuel !== '' && carFuel !== fuel) {
      matchesFilter = false;
    }
    if (transmission && transmission !== '' && carTransmission !== transmission) {
      matchesFilter = false;
    }
    if (color && color !== '' && carColor !== color) {
      matchesFilter = false;
    }
    if (model && model !== '' && carModel !== model) {
      matchesFilter = false;
    }

    // Filtreyi geçen arabaları ekle
    if (matchesFilter) {
      card.style.display = 'block';
      carContainer.appendChild(card); // Filtrelenen araçları ekleyin
    } else {
      card.style.display = 'none';
    }
  });

  updatePagination();
  showPage(currentPage);
}

// Sayfa numaralarını oluştur
function updatePagination() {
  paginationContainer.innerHTML = '';
  for (let i = 1; i <= totalPages; i++) {
    const pageLink = document.createElement('button');
    pageLink.classList.add('page-link');
    pageLink.textContent = i;
    pageLink.onclick = function() {
      currentPage = i;
      showPage(i);
    };
    paginationContainer.appendChild(pageLink);
  }
  document.body.appendChild(paginationContainer);
}

// Sayfa içeriğini göster
function showPage(page) {
  const carCards = document.querySelectorAll('.car-card');
  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;

  carCards.forEach((card, index) => {
    if (index >= startIndex && index < endIndex) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}

// Sayfa yüklenince başlangıçta filtreleme ve sayfa yükleme
window.onload = function() {
  filterCars(); // Başlangıçta tüm arabaları göster
  showPage(currentPage);
};

// Filtrelerin sıfırlanması için her "Seçin..." tıklamasını dinleme
document.querySelectorAll('select').forEach(selectElement => {
  selectElement.addEventListener('change', function() {
    // Eğer "Seçin..." seçeneği seçildiyse, filtreleme sıfırlansın
    if (this.value === '') {
      filterCars(); // Tüm arabaları göster
    }
  });
});



