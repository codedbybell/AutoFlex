// Detaylar sayfasına giderken, URL'ye arabayla ilgili verileri geçireceğiz.
// Bu veri JavaScript ile alınarak sayfada gösterilecek.

const urlParams = new URLSearchParams(window.location.search);
const carId = urlParams.get('carId'); // URL'den araç kimliğini alıyoruz (carId)

const carDetails = {
  1: {
    title: '2023 BMW Cabrio',
    price: 1000,
    km: '50.000 km',
    color: 'White',
    fuel: 'Gas',
    transmission: 'Manual',
    model: 'Cabrio',
    city: 'İstanbul',
    description: '2023 model, low km, well maintained and trouble-free.',
    imgSrc: 'bmw1.jpeg',
    additionalImages: [
      'bmw1.jpeg',
      'bmw2.jpeg',
      'bmw3.jpeg',
      'bmw4.jpeg',
      'bmw5.jpeg',
      'bmw6.jpeg',
    ]
  },
  2: {
    title: '2021 Ford Kuga',
    price: 500,
    km: '80.000 km',
    color: 'White',
    fuel: 'Diesel',
    transmission: 'Automatic',
    model: 'SUV',
    city: 'Ankara',
    description: 'Dizel motor, otomatik vites, bakımlı.',
    imgSrc: 'SUV.jpeg',
    additionalImages: [
      
    ]
  },
  3: {
    title: '2020 Clio',
    price: 200,
    km: '30.000 km',
    color: 'White',
    fuel: 'Gas',
    transmission: 'Automatic',
    model: 'Hatchback',
    city: 'İstanbul',
    description: 'Dizel motor, otomatik vites, bakımlı.',
    imgSrc: 'clio.jpeg',
    additionalImages: [
      
    ]
  },
  4: {
    title: '2024 mercedes e200',
    price: 1100,
    km: '44.000 km',
    color: 'Black',
    fuel: 'Gas',
    transmission: 'Automatic',
    model: 'Sedan',
    city: 'İzmir',
    description: 'Dizel motor, otomatik vites, bakımlı.',
    imgSrc: 'mercedes.jpeg',
    additionalImages: [
      
    ]
  },
  5: {
    title: '2020 A3 Hatchback',
    price: 750,
    km: '65.000 km',
    color: 'White',
    fuel: 'Gas',
    transmission: 'Automatic',
    model: 'Hatchback',
    city: 'İstanbul',
    description: 'Our vehicle has a diesel engine and automatic transmission. It has been regularly maintained and has low mileage.',
    imgSrc: 'audi.jpeg',
    additionalImages: [
      'audi2.jpeg',
      'audi3.jpeg',
      'audi4.jpeg',
      'audi5.jpeg',
      'audi6.jpeg',
      'audi7.jpeg',
      'audi8.jpeg',
      
    ]
  },
  

};

// carId'yi kullanarak doğru araba bilgilerini getiriyoruz
const car = carDetails[carId];

if (car) {
  document.getElementById('carDetailTitle').innerText = car.title;
  document.getElementById('carDetailPrice').innerText = car.price;
  document.getElementById('carDetailKm').innerText = car.km;
  document.getElementById('carDetailColor').innerText = car.color;
  document.getElementById('carDetailFuel').innerText = car.fuel;
  document.getElementById('carDetailTransmission').innerText = car.transmission;
  document.getElementById('carDetailModel').innerText = car.model;
  document.getElementById('carDetailCity').innerText = car.city;
  document.getElementById('carDetailDescription').innerText = car.description;

  // Ana resmi güncelle
  document.getElementById('carMainImage').src = car.imgSrc;
  document.getElementById('carMainImageLink').href = car.imgSrc;

  // Küçük resim galerisi için ek resimler ekle
  const thumbnailGallery = document.getElementById('carThumbnailGallery');
  thumbnailGallery.innerHTML = ''; // Eski içeriği temizle

  car.additionalImages.slice(0, 10).forEach((imgSrc) => {
    const imgElement = document.createElement('img');
    imgElement.src = imgSrc;
    imgElement.className = 'car-thumbnail';
    imgElement.onclick = () => changeImage(imgSrc);
    thumbnailGallery.appendChild(imgElement);
  });
}

function changeImage(src) {
  document.getElementById('carMainImage').src = src;
  document.getElementById('carMainImageLink').href = src;
}



// Modal'ı açma işlevi
function openModal() {
  document.getElementById("phoneModal").style.display = "block";
}

// Modal'ı kapatma işlevi
function closeModal() {
  document.getElementById("phoneModal").style.display = "none";
}

// Kullanıcı modal dışında bir yere tıklarsa modal'ı kapat
window.onclick = function(event) {
  const modal = document.getElementById("phoneModal");
  if (event.target === modal) {
    modal.style.display = "none";
  }
};





